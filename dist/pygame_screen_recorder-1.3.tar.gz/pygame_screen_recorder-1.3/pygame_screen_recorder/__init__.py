# __init__.py
from .pygame_screen_recorder import pygame_screen_recorder

__version__ = "1.0.0"